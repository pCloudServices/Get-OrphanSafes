###########################################################################
#
# NAME: Get-OrphanedSafes
#
# AUTHOR:  Mike Brook<mike.brook@cyberark.com>
#
# COMMENT: 
# Script will attempt to check which safes are fully manageable, segregated managealbe, and lastly orphan (meaning no way to access or manage the safe).
#
#
###########################################################################
param(
    [ValidateScript({
        If(![string]::IsNullOrEmpty($_)) {
            $isValid = ($_ -like "*.privilegecloud.cyberark.cloud*") -or ($_ -like "*.cyberark.cloud*")
            if (-not $isValid) {
                throw "Invalid URL format. Please specify a valid Privilege Cloud tenant URL (e.g.https://<subdomain>.cyberark.cloud)."
            }
            $true
        }
        Else {
            $true
        }
    })]
    [Parameter(Mandatory = $true, HelpMessage = "Specify the URL of the Privilege Cloud tenant (e.g., https://<subdomain>.cyberark.cloud)")]
    [string]$PortalURL,
    [Parameter(Mandatory = $true, HelpMessage = "Specify a User that has at minimum Audit permissions.")]
    [PSCredential]$Credentials,
    [Parameter(Mandatory = $false, HelpMessage = "Enter a file path for bulk safes")]
    [ValidateScript( { Test-Path -Path $_ -PathType Leaf -IsValid })]
    [ValidatePattern('\.(csv|txt)$')]
    [Alias("File")]
    [String]$SafesFromFile,
    [Parameter(Mandatory = $False)]
    [ValidateSet("cyberark","identity")]
    [string]$ForceAuthType,
    [Parameter(Mandatory = $False, HelpMessage = "Specify the execution mode: BasicAudit or ComprehensiveAudit.")]
    [ValidateSet("BasicAudit","ComprehensiveAudit")]
    [string]$ExecutionMode
)


# Modules
$mainModule = "Import_AllModules.psm1"

$modulePaths = @(
"..\\PS-Modules\\$mainModule",
"..\\..\\PS-Modules\\$mainModule",
".\\PS-Modules\\$mainModule", 
".\\$mainModule"
"..\\$mainModule"
".\\..\\$mainModule"
"..\\..\\$mainModule"
)

foreach ($modulePath in $modulePaths) {

    if (Test-Path $modulePath) {
        try {
            Import-Module $modulePath -ErrorAction Stop -DisableNameChecking -Force
        } catch {
            Write-Host "Failed to import module from $modulePath. Error: $_"
            Write-Host "check that you copied the PS-Modules folder correctly."
            Pause
            Exit
        }
     }
}

$ScriptLocation = Split-Path -Parent $MyInvocation.MyCommand.Path
$global:LOG_FILE_PATH = "$ScriptLocation\_Get-OrphanedSafes.log"

[int]$scriptVersion = 1

# PS Window title
$Host.UI.RawUI.WindowTitle = "Privilege Cloud Get OrphanedSafes Script"

## Force Output to be UTF8 (for OS with different languages)
$OutputEncoding = [Console]::InputEncoding = [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding

# Minimal permissions required to fully control a safe, ("Manage safe" or "Manage Safe Members" is not enough unfortunately).
$global:SafePermissionsMinimum = @(
    "useAccounts",
    "retrieveAccounts",
    "listAccounts",
    "addAccounts",
    "updateAccountContent",
    "updateAccountProperties",
    "initiateCPMAccountManagementOperations",
    "specifyNextAccountContent",
    "renameAccounts",
    "deleteAccounts",
    "unlockAccounts",
    "manageSafe",
    "manageSafeMembers",
    "viewAuditLog",
    "viewSafeMembers",
    "accessWithoutConfirmation"
)


# Builtin safes to exclude
$excludeBuiltInSafes = @(
    'Notification Engine',
    'Pictures',
    'System',
    'VaultInternal',
    'Telemetry_Config',
    'SharedAuth_Internal',
    'AccountsFeedADAccounts',
    'AccountsFeedDiscoveryLogs',
    'PasswordManager Safe',
    'PasswordManagerShared Safe',
    'PasswordManager_Pending',
    'PasswordManagerTemp',
    'PVWAConfig',
    'PVWAUserPrefs',
    'PVWATicketingSystem',
    'PVWAPrivateUserPrefs',
    'PVWAReports',
    'PVWATaskDefinitions',
    'PVWAPublicData',
    'PSM',
    'PSMSessions',
    'PSMLiveSessions',
    'PSMUnmanagedSessionAccounts',
    'PSMNotifications',
    'PSMUniversalConnectors',
    'PSMPConf',
    'PSMPLiveSessions',
    'PSMPADBUserProfile',
    'PSMPADBridgeCustom',
    'PSMPADBridgeConf',
    'AppProviderCacheSafe',
    'TelemetryConfig'
)

$excludeBuiltInUsers = @(
    'Master',
    'Batch',
    'Backup Users',
    'Operators',
    'Notification Engines',
    'PSMAppUsers',
    'DR Users',
    'CyberarkAccountsIntegration',
    'Auditors'
)

$global:SafeManagerPermissions = @(
    "listAccounts", "addAccounts", "updateAccountContent", "updateAccountProperties",
    "initiateCPMAccountManagementOperations", "renameAccounts",
    "deleteAccounts", "unlockAccounts", "manageSafe", "manageSafeMembers", "viewSafeMembers"
)

$global:EndUserPermissions = @(
    "useAccounts", "retrieveAccounts", "listAccounts"
)

Function Export-SafeDataToCsv {
    param(
        [Parameter(Mandatory = $true)]
        $Owner,

        [Parameter(Mandatory = $true)]
        [string]$OutputCsvPath
    )

    [PSCustomObject]@{
        Safe = $Owner.safeName
        memberName = $Owner.memberName -join ', '
        memberType = $Owner.memberType -join ', '
        useAccounts = $Owner.permissions.useAccounts -join ', '
        retrieveAccounts = $Owner.permissions.retrieveAccounts -join ', '
        listAccounts = $Owner.permissions.listAccounts -join ', '
        addAccounts = $Owner.permissions.addAccounts -join ', '
        updateAccountContent = $Owner.permissions.updateAccountContent -join ', '
        updateAccountProperties = $Owner.permissions.updateAccountProperties -join ', '
        initiateCPMAccountManagementOperations = $Owner.permissions.initiateCPMAccountManagementOperations -join ', '
        specifyNextAccountContent = $Owner.permissions.specifyNextAccountContent -join ', '
        renameAccounts = $Owner.permissions.renameAccounts -join ', '
        deleteAccounts = $Owner.permissions.deleteAccounts -join ', '
        unlockAccounts = $Owner.permissions.unlockAccounts -join ', '
        manageSafe = $Owner.permissions.manageSafe -join ', '
        manageSafeMembers = $Owner.permissions.manageSafeMembers -join ', '
        backupSafe = $Owner.permissions.backupSafe -join ', '
        viewAuditLog = $Owner.permissions.viewAuditLog -join ', '
        viewSafeMembers = $Owner.permissions.viewSafeMembers -join ', '
        accessWithoutConfirmation = $Owner.permissions.accessWithoutConfirmation -join ', '
        createFolders = $Owner.permissions.createFolders -join ', '
        deleteFolders = $Owner.permissions.deleteFolders -join ', '
        moveAccountsAndFolders = $Owner.permissions.moveAccountsAndFolders -join ', '
        requestsAuthorizationLevel1 = $Owner.permissions.requestsAuthorizationLevel1 -join ', '
        requestsAuthorizationLevel2 = $Owner.permissions.requestsAuthorizationLevel2 -join ', '
    } | Export-Csv -Delimiter "," -Path $OutputCsvPath -Append -Force -NoTypeInformation
}



# Init filenames
$output_SafesNotFound = "$ScriptLocation\$($PlatformTenantId)_$(Get-Date -Format 'yyyy-MM-dd_HH\hmm\m') Safes Not Found.csv"
$output_OrphanedSafes = "$ScriptLocation\$($PlatformTenantId)_$(Get-Date -Format 'yyyy-MM-dd_HH\hmm\m') Safes Orphaned.csv"
$output_RecoverableFullAccessSafes = "$ScriptLocation\$($PlatformTenantId)_$(Get-Date -Format 'yyyy-MM-dd_HH\hmm\m') Safes Full permissions.csv"
$output_RecoverableCombinedAccessSafes = "$ScriptLocation\$($PlatformTenantId)_$(Get-Date -Format 'yyyy-MM-dd_HH\hmm\m') Safes Combined permissions.csv"
$output_UnableToAccessSafes = "$ScriptLocation\$($PlatformTenantId)_$(Get-Date -Format 'yyyy-MM-dd_HH\hmm\m') Safes Unable To Access.csv"

# Check files don't exist before every run.
if (Test-Path $output_SafesNotFound) {
    Remove-Item $output_SafesNotFound -Force
}
if (Test-Path $output_OrphanedSafes) {
    Remove-Item $output_OrphanedSafes -Force
}
if (Test-Path $output_RecoverableFullAccessSafes) {
    Remove-Item $output_RecoverableFullAccessSafes -Force
}
if (Test-Path $output_UnableToAccessSafes) {
    Remove-Item $output_UnableToAccessSafes -Force
}
if (Test-Path $output_RecoverableFullAccessSafes) {
    Remove-Item $output_RecoverableFullAccessSafes -Force
}


Function Check-RequiredPermissionsFULL {
    param (
        [PSCustomObject]$permissions
    )
    
    $hasRequiredPermissions = $true
    foreach ($perm in $global:SafePermissionsMinimum) {
        if (-not $permissions.$perm) {
            $hasRequiredPermissions = $false
            break
        }
    }
    
    return $hasRequiredPermissions
}

Function Check-SegregatedManageable {
    param (
        [Parameter(Mandatory = $true)]
        $SafeMembers # Array of objects representing the members and their permissions
    )

    $safeManagerGroups = @()
    $endUserEntities = @() # Can be users or groups

    foreach ($member in $SafeMembers) {
        if ($member.memberType -eq "User" -and $member.isPredefinedUser -eq $false) {
            # Check if this user can be considered as an End User
            $isEndUser = $member.permissions.listAccounts -eq $true -and 
                         ($member.permissions.useAccounts -eq $true -or $member.permissions.retrieveAccounts -eq $true)

            if ($isEndUser) {
                $endUserEntities += $member
            }
        }
        elseif ($member.memberType -eq "Group") {
            # Check for Safe Manager permissions within groups
            $isSafeManager = $true
            foreach ($perm in $global:SafeManagerPermissions) {
                if (-not $member.permissions.$perm -eq $true) {
                    $isSafeManager = $false
                    break
                }
            }

            if ($isSafeManager) {
                $safeManagerGroups += $member
            }
            # Also check if group can be considered as an End User
            $isEndUser = $member.permissions.listAccounts -eq $true -and 
                         ($member.permissions.useAccounts -eq $true -or $member.permissions.retrieveAccounts -eq $true)

            if ($isEndUser) {
                $endUserEntities += $member
            }
        }
    }

    # Ensure segregation: at least one group must be a Safe Manager and at least one entity (user or group) must be an End User
    if ($safeManagerGroups -and $endUserEntities) {
        return @{
            SafeManagers = $safeManagerGroups
            EndUsers = $endUserEntities
        }
    }
    else {
        return $null
    }
}


Function FilterOutBuiltInSafes ($safes){
      Write-LogMessage -type Info -MSG "Filtering Builtin Safes" -Early
      # Dynamically identify base names of CPM safes and add to exclusion list
      $dynamicSafePatterns = @('_Workspace$', '_Info$', '_ADInternal$', '_Accounts$', '_Pending')
      $baseNames = @()
      
      foreach ($safe in $safes) {
          foreach ($pattern in $dynamicSafePatterns) {
              if ($safe -match $pattern) {
                  # Extract base name by removing the dynamic part
                  $baseName = $safe -replace $pattern, ''
                  $baseNames += $baseName
                  break
              }
          }
      }
      
      $baseNames = $baseNames | Select-Object -Unique
      
      # Combine lists
      $combinedExclusions = $excludeBuiltInSafes + $baseNames

      # Init count
      $originalCount = $safes.Count
   
      # Filter the $safes array
      $filteredSafes = $safes | Where-Object {
      $safe = $_
      $exclude = $false

      # Check for combined exclusions
      if ($combinedExclusions -contains $safe) {
          $exclude = $true
      }

      # Handle CPM patterns
      foreach ($pattern in $dynamicSafePatterns) {
          if ($safe -match $pattern) {
              $exclude = $true
              break
          }
      }

      # Exclude the safe if $exclude is true
      -not $exclude
      }
      $filteredOutCount = $originalCount - $filteredSafes.Count
      Write-LogMessage -type Info -MSG "Filtered out $($filteredOutCount) BuiltIn safes" -Early

      return $filteredSafes
}



# Main
Try{

    # Select mode if not ran from command line
    if (-not $ExecutionMode) {
        $ExecutionMode = Get-Choice -Title "Select Execution Mode" -Options @("BasicAudit", "ComprehensiveAudit")
        Write-LogMessage -type Info -MSG "Running in $($ExecutionMode) mode." -Early
        Start-Sleep 2
        Write-LogMessage -type Warning -MSG "You should run the script with -BasicAudit or -ComprehensiveAudit flag to skip this prompt each time."
        Start-Sleep 5
    }

    # Build PVWA Urls
    $platformURLs = DetermineTenantTypeURLs -PortalURL $PortalURL
    $IdentityAPIURL = $platformURLs.IdentityURL
    $pvwaAPI = $platformURLs.PVWA_API_URLs.PVWAAPI
    
    # Auditor related
    $URL_UsersGroups = $pvwaAPI + "/UserGroups"
    $URL_UserSetGroup = $URL_UsersGroups + "/{0}/Members"
    $URL_UserDelGroup = $URL_UsersGroups + "/{0}/Members/{1}"

    # Login
    if($ForceAuthType){
        $logonheader = Authenticate-Platform -platformURLs $platformURLs -creds $Credentials -ForceAuthType $ForceAuthType
    }Else{
        $logonheader = Authenticate-Platform -platformURLs $platformURLs -creds $Credentials
    }
    if(-not($logonheader.Authorization)){
        Write-Host "Failed to get Token, exiting..."
        Exit
    }

    # Check if user has Safe Auditors permissions
    $Get_CurrentAuditorGroupAndMembers = Get-AuditorsGroup -URLAPI $pvwaAPI -logonheader $logonheader
    Write-LogMessage -type Info -MSG "Checking if user: $($Credentials.UserName) has Safe Auditor permissions.." -Early
    if ($Get_CurrentAuditorGroupAndMembers.members.username -contains $Credentials.UserName){
        Write-LogMessage -type Info -MSG "User has Auditor permission, proceeding." -Early
    }Else{
        Write-LogMessage -type Warning -MSG "User $($Credentials.UserName) doesn't have Auditor permissions, please be advised you may not see all available safes."
        $userDecision = Read-Host "You do not have Auditor permissions. Do you want to continue anyway? (Y/N)"
        if ($userDecision -ne 'Y') {
            Write-LogMessage -type Info -MSG "User chose not to proceed. Exiting script." -Early
            Pause
            Exit
        }
        else{
            Write-LogMessage -type Info -MSG "User chose to proceed." -Early
        }
    }

    # Insert/Remove user from Auditors group
      $AuditorsId = (Get-AuditorsGroup -URLAPI $pvwaAPI -logonheader $logonHeader).id
      Insert-AuditorsGroup -UsernameToAdd $Credentials.UserName -URLAPI $pvwaAPI -AuditorsId $AuditorsId -logonheader $logonheader

    if (-not($SafesFromFile)) {
        $validChoice = $false
    
        do {
            Write-Host "=====================================================" -ForegroundColor Cyan
            Write-LogMessage -type Warning -MSG "Since you didn't provide a file using the -SafesFromFile flag when you ran the script."
            Write-LogMessage -type Warning -MSG "Here are the other options you can choose from: "
            Write-Host "=====================================================" -ForegroundColor Cyan
    
            Write-Host "1. Provide a filename now." -ForegroundColor Magenta
            Write-Host "2. Type the safename manually (multiple safes can be typed using ',' comma char)." -ForegroundColor Magenta
            Write-Host "3. Select specific safes from all available Safes in the vault." -ForegroundColor Magenta
            Write-Host "4. Check all available Safes in the vault." -ForegroundColor Magenta
            Write-Host "Q. Press Q to quit." -ForegroundColor Red
            Write-Host "=====================================================" -ForegroundColor Cyan
    
            $choice = Read-Host "Please enter your choice (1-4) or Q to quit"
    
            switch ($choice) {
                "1" {
                    Write-Host "You chose to provide a filename: $filename" -ForegroundColor Green
                    $validChoice = $true
                    $Safes = gc $(Get-UserFile)
                }
                "2" {
                    $safenamesInput = Read-Host "Type the safename(s) manually, separated by commas"
                    $safes = $safenamesInput -split ',\s*'
                    Write-Host "You chose to manually type safename(s): $safenamesInput" -ForegroundColor Green
                    $validChoice = $true
                }
                "3" {
                    Write-Host "You chose to get all Safes and select specific ones." -ForegroundColor Green
                    $validChoice = $true
                    $Get_Safes = Get-Safes -URLAPI $pvwaAPI -logonHeader $logonheader
                    # Filter builtin before showing the option
                    $filteredSafes = FilterOutBuiltInSafes $($Get_Safes.safename)
                    Write-LogMessage -type Info -MSG "Safes count after filter $($filteredSafes.count)" -Early
                    $safes = $filteredSafes | Out-GridView -PassThru -Title "Select Safes"
                    if ($safes) {
                        Write-Host "You have selected the following safes:" -ForegroundColor Green
                        $safes | ForEach-Object { Write-Host $_ -ForegroundColor Cyan }
                    } else {
                        Write-Host "No safes were selected." -ForegroundColor Red
                    }
                }
    
                "4" {
                    Write-Host "You chose to get all Safes and work on them." -ForegroundColor Green
                    $validChoice = $true
                    $Get_Safes = Get-Safes -URLAPI $pvwaAPI -logonHeader $logonheader
                    $filteredSafes = FilterOutBuiltInSafes $($Get_Safes.safename)
                    Write-LogMessage -type Info -MSG "Safes count after filter $($filteredSafes.count)" -Early
                    $safes = $filteredSafes
                }
                "Q" {
                    Write-Host "Quitting..." -ForegroundColor Red
                    $validChoice = $true
                    Exit
                }
                default {
                    Write-Host "Invalid choice. Please select a valid option." -ForegroundColor Red
                }
            }
        } while (-not $validChoice)
        } else {
            if (Test-Path -Path $SafesFromFile) {
                $Safes = Get-Content $SafesFromFile
            } else {
                Write-Host "The file path '$SafesFromFile' does not exist or is not accessible." -ForegroundColor Red
                exit
            }
        }
    
    # filter out PPA (Personal Privileged Account) safes as these are personal safes and shouldn't be passed to another person.
    Write-LogMessage -type Info -MSG "Filtering out all the PPA (Personal Privileged Account) Safes" -Early
    $safes = $safes | where {$_ -notlike "PPA_I_*"}
    Write-LogMessage -type Info -MSG "Safes count after filter $($safes.count)" -Early
    Start-Sleep 2

    # Iterate through the list provided and get member details and permissions for each safe and store it in a variable.
    Write-LogMessage -type Info -MSG "Start checking safes." -Early
    Foreach ($Safe in $safes){
        $ownersList = $null
        $safeOwnersFULL = $null
        $safeOwners = $null
        $segregatedManageable = $null

        Try
        {
            # Get Owner list for each Safe
            $ownersList = Invoke-RestMethod -Uri ("$pvwaAPI/Safes/$($safe)/Members?filter=includePredefinedUsers eq true") -Method Get -Headers $logonHeader -ContentType "application/json" -ErrorVariable pvwaERR
        }
        Catch
        {
            write-host $_.ErrorDetails.Message -ForegroundColor Gray
            # In case of acess errors
            if($_.ErrorDetails.Message -like "*unauthorized to view owners*"){
                    Write-LogMessage -type Warning -MSG "Unable to process safe $safe"
                    Write-Host ""
                    [PSCustomObject]@{
                    Safe = $Safe
                    ErrorDisplay = $_.ErrorDetails.Message
                    } | Export-Csv -Delimiter "," $output_UnableToAccessSafes -Append -Force -NoTypeInformation
                    $WarningAccess = $true
            }
            Elseif($_.ErrorDetails.Message -like "*was not found*"){
               Write-LogMessage -type Warning -MSG "Safe '$($safe)' not found!"
                [PSCustomObject]@{
                    SafeNotFound = $Safe
                    } | Export-Csv -Delimiter "," $output_SafesNotFound -Append -Force -NoTypeInformation
                Write-Host ""
            }   
            Else{
                Write-Host "Couldn't get Safe owners for safe '$($safe)', fix it and rerun the script"
                Write-Host ""
            }
        }
            # Check Owner permissions
            $safeOwners = $ownersList.value | where {$_.safeName -eq $safe -and ($_.memberName -notin $excludeBuiltInUsers)} | select safeName,memberName,memberType,permissions
            $safeOwnersFULL = $ownersList.value | where {$_.safeName -eq $Safe -and (Check-RequiredPermissionsFULL -permissions $_.permissions) -and ($_.memberName -notin $excludeBuiltInUsers)} | select safeName,memberName,memberType,permissions
            $segregatedManageable = $ownersList.value | where {$_.safeName -eq $Safe -and (Check-SegregatedManageable -SafeMembers $ownersList.value) -and ($_.memberName -notin $excludeBuiltInUsers)} | select safeName,memberName,memberType,permissions
            
            # If any owners have full permissions to manage safe.
            if($ExecutionMode -and $safeOwnersFULL){
                Write-Host "Safe '$($Safe)' is OK, it has the following member/s that can manage it:" -ForegroundColor Green
                $($safeOwnersFULL.memberName) | Write-host -ForegroundColor blue -BackgroundColor Gray
                Write-Host ""
                foreach($owner in $safeOwnersFULL){               
                    Export-SafeDataToCsv -Owner $owner -OutputCsvPath $output_RecoverableFullAccessSafes
                }
            }
            ElseIf($ExecutionMode -eq "ComprehensiveAudit" -and ($segregatedManageable) -and ($ownersList)){
                write-host "Safe '$($Safe)' is OK, it has the following" -ForegroundColor Green -NoNewline ; Write-Host " Combination " -ForegroundColor Yellow -BackgroundColor Magenta -NoNewline;Write-Host  "of member/s that can manage it:" -ForegroundColor Green
                $($segregatedManageable.memberName) | Write-host -ForegroundColor blue -BackgroundColor Gray
                Write-Host ""
                foreach($owner in $segregatedManageable){               
                    Export-SafeDataToCsv -Owner $owner -OutputCsvPath $output_RecoverableCombinedAccessSafes
                }
            }
             # If we got some type of response but the owners list we're looking for comes back empty, safe is orphan.
            Elseif(($safeOwnersFULL -eq $null) -and ($segregatedManageable -eq $null) -and ($ownersList)){
                $safeOwners = $ownersList.value | where {$_.safeName -eq $safe -and ($_.memberName -notin $excludeBuiltInUsers)} | select safeName,memberName,memberType,permissions
                #$safeOwners = $ownersList.value | where {$_.safeName -eq $safe} | select safeName,memberName,memberType,permissions
                Write-Host "Safe '$($Safe)' is Orphaned" -ForegroundColor Red
                Write-Host ""
                if ($safeOwners -eq $null){
                    [PSCustomObject]@{
                        Safe = $Safe
                        memberName = "** NO SAFE OWNERS FOUND **"  
                    } | Export-Csv -Delimiter "," $output_OrphanedSafes -Append -Force -NoTypeInformation
                }
                Else
                {
                    foreach($owner in $safeOwners){               
                        Export-SafeDataToCsv -Owner $owner -OutputCsvPath $output_OrphanedSafes
                    }
                }
          }
    }
    # In case permission related errors, lets tell the user they should address those.
    Write-Host ""
    Write-Host "***"
    Write-LogMessage -type Success -MSG "****** Results saved under `"$ScriptLocation`" ******"
    Write-Host "***"
    if($WarningAccess){
        Write-LogMessage -type Warning -MSG "We noticed some safes were inaccessible, you should run the script with a user that has Audit permissions"
    }
}
Catch{
        # Output the terminating error
        Write-LogMessage -Type Error -Msg "Error: $(Collect-ExceptionMessage $_.exception.message $($_.ErrorDetails.Message) $($_.exception.status) $($_.exception.Response.ResponseUri.AbsoluteUri))"
}
Finally{
        # In case command errors in the middle of the loop, lets logoff and clean creds
        Try{Extract-AuditorsGroup -UsernameToRemove $Credentials.UserName -URLAPI $pvwaAPI -AuditorsId $AuditorsId -logonheader $logonheader}Catch{}
        # Logoff
        Try{Invoke-RestMethod -Uri $URL_PVWALogoff -Method Post -Headers $logonHeader | Out-Null}Catch{}
}